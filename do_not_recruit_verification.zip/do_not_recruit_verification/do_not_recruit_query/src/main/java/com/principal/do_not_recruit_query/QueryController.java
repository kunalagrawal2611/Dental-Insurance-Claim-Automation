package com.principal.do_not_recruit_query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
public class QueryController {
    @Autowired
    QueryService queryService;

    @RequestMapping("/get/doNotRecruitLookup")
    public ReturningJson getDo_not_recruit(@RequestParam String firstname, @RequestParam String lastname, @RequestParam String npi){
        return queryService.getByParam(firstname,lastname,npi);
    }

    @RequestMapping("/get/doNotRecruitLookup/tin")
    public ReturningTin getDo_not_recruit(@RequestParam String tin){
        return queryService.getByTin(tin);
    }
}
