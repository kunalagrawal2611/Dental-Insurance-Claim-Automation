package com.principal.do_not_recruit_query;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Do_not_query_Repository extends MongoRepository<Do_not_recruit,String> {
   // public List<Do_not_recruit> findByFirstname(String firstName);
    public List<Do_not_recruit> findByNpi(String npi);
    public List<Do_not_recruit> findByTin(String tin);
    
}
