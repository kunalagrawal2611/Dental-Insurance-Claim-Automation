package com.principal.do_not_recruit_query;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoNotRecruitQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoNotRecruitQueryApplication.class, args);
	}

}
