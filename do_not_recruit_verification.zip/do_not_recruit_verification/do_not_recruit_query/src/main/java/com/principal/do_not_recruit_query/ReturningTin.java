package com.principal.do_not_recruit_query;


import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ReturningTin {
    public String tinMatched;

    public ReturningTin(String status) {
        this.tinMatched = status;
    }
}
