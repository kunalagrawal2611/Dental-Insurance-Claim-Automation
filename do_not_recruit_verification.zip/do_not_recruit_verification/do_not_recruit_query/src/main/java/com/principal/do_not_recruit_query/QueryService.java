package com.principal.do_not_recruit_query;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class QueryService {
    @Autowired
    private Do_not_query_Repository queryrepository;

    public ReturningJson getByParam(String firstname, String lastname, String npi) {

        List<Do_not_recruit> do_not_recruit = queryrepository.findByNpi(npi);
        //List<Do_not_recruit> do_not_recruit = queryrepository.findByNpi(npi);

        int first_length = firstname.length();
        int last_length = lastname.length();



        if (first_length>2 && last_length>2) {

          //  System.out.println(first_length);
            String first_url = firstname.substring(0, 3);
            String last_url = lastname.substring(0, 3);

            if (do_not_recruit != null) {
                for (Do_not_recruit itr : do_not_recruit) {
                    if (itr != null) {
                        String first = itr.firstname.substring(0, 3);
                        String last = itr.lastname.substring(0, 3);

                        if (itr.npi.equals(npi) && first.equalsIgnoreCase(first_url) && last.equalsIgnoreCase(last_url)) {

                            return new ReturningJson("yes", "yes");
                        } else if (itr.npi.equals(npi)) {
                            if (!first_url.equalsIgnoreCase(first)) {
                                return new ReturningJson("no", "yes");
                            } else if (!last.equalsIgnoreCase(last_url)) {
                                return new ReturningJson("no", "yes");
                            }
                        }
                    }
                }
            }
        }
        else if (first_length<3 && last_length<3) {
            String first_url = firstname.substring(0, first_length);
            String last_url = lastname.substring(0, last_length);

            if (do_not_recruit != null) {
                for (Do_not_recruit itr : do_not_recruit) {
                    if (itr != null) {
                        String first = itr.firstname.substring(0, first_length);
                        String last = itr.lastname.substring(0, last_length);

                        if (itr.npi.equals(npi) && first.equalsIgnoreCase(first_url) && last.equalsIgnoreCase(last_url)) {

                            return new ReturningJson("yes", "yes");
                        } else if (itr.npi.equals(npi)) {
                            if (!first_url.equalsIgnoreCase(first)) {
                                return new ReturningJson("no", "yes");
                            } else if (!last.equalsIgnoreCase(last_url)) {
                                return new ReturningJson("no", "yes");
                            }
                        }
                    }
                }
            }
        }
        else if (first_length<3 && last_length>2) {
            String first_url = firstname.substring(0, first_length);
            String last_url = lastname.substring(0, 3);

            if (do_not_recruit != null) {
                for (Do_not_recruit itr : do_not_recruit) {
                    if (itr != null) {
                        String first = itr.firstname.substring(0, first_length);
                        String last = itr.lastname.substring(0, 3);

                        if (itr.npi.equals(npi) && first.equalsIgnoreCase(first_url) && last.equalsIgnoreCase(last_url)) {

                            return new ReturningJson("yes", "yes");
                        } else if (itr.npi.equals(npi)) {
                            if (!first_url.equalsIgnoreCase(first)) {
                                return new ReturningJson("no", "yes");
                            } else if (!last.equalsIgnoreCase(last_url)) {
                                return new ReturningJson("no", "yes");
                            }
                        }
                    }
                }
            }
        }
        else if (first_length>2 && last_length<3) {
            String first_url = firstname.substring(0, 3);
            String last_url = lastname.substring(0, last_length);

            if (do_not_recruit != null) {
                for (Do_not_recruit itr : do_not_recruit) {
                    if (itr != null) {
                        String first = itr.firstname.substring(0, 3);
                        String last = itr.lastname.substring(0, last_length);

                        if (itr.npi.equals(npi) && first.equalsIgnoreCase(first_url) && last.equalsIgnoreCase(last_url)) {

                            return new ReturningJson("yes", "yes");
                        } else if (itr.npi.equals(npi)) {
                            if (!first_url.equalsIgnoreCase(first)) {
                                return new ReturningJson("no", "yes");
                            } else if (!last.equalsIgnoreCase(last_url)) {
                                return new ReturningJson("no", "yes");
                            }
                        }
                    }
                }
            }
        }
        return new ReturningJson("no","no");
    }

    public ReturningTin getByTin(String tin) {
        List<Do_not_recruit> do_not_recruits = queryrepository.findByTin(tin);
        if(do_not_recruits!=null) {
            for (Do_not_recruit itr1 : do_not_recruits) {
                if(itr1!=null && itr1.tin.equalsIgnoreCase(tin)) {
                    return new ReturningTin("yes");
                }
            }
        }
        return new ReturningTin("no");
    }

}

