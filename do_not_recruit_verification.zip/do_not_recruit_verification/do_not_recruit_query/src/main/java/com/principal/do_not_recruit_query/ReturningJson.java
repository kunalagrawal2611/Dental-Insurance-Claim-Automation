package com.principal.do_not_recruit_query;


import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ReturningJson {
    public String nameMatched;
    public String npiMatched;

   // public ReturningJson(){}

    public ReturningJson(String status1, String status2){
        this.nameMatched = status1;
        this.npiMatched=status2;
    }
}
