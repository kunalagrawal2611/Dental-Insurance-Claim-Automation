package com.principal.do_not_recruit_query;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoNotRecruitQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
