package com.example.demo;


import java.util.Date;

public class Do_not_recruit {

    public String tin;
    public String provider_id;
    public String npi;
    public String firstname;
    public String lastname;
    public String location_id;
    public String address;
    public String city;
    public String state;
    public String zip;
    public Date date;



    public Do_not_recruit(String tin,String provider_id,String npi,String firstname,
                          String lastname,String location_id, String address,String city,
                          String state,String zip,Date date) {
        this.tin=tin;
        this.provider_id=provider_id;
        this.npi=npi;
        this.firstname = firstname;
        this.lastname=lastname;
        this.location_id=location_id;
        this.address=address;
        this.city=city;
        this.state = state;
        this.zip=zip;
        this.date=date;
    }

    @Override
    public String toString() {
        return tin+" "+provider_id+" "+npi+" "+firstname+" "+lastname+" "+location_id+" "+address
                +" "+city+" "+state+" "+zip+" "+date;
    }
}