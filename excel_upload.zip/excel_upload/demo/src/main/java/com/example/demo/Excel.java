 package com.example.demo;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.*;


 public class Excel {

	public static List<Do_not_recruit> readExcelData(File file)throws Exception {


		List<Do_not_recruit> res = new ArrayList<>();

		DataFormatter formatter = new DataFormatter();
		Workbook wb = WorkbookFactory.create(file);


			Sheet sh = wb.getSheetAt(0);


			int rownum = sh.getPhysicalNumberOfRows();

			System.out.println(rownum);

			for (int i = 1; i < rownum; i++) {

				if (sh.getRow(i) == null) continue;

				System.out.println("Cell1");
				Cell cell1 = sh.getRow(i).getCell(0);
				cell1.setCellType(Cell.CELL_TYPE_STRING);
				String tin = cell1.getStringCellValue();
				if (tin.equalsIgnoreCase(null)) {
					break;
				}

				System.out.println("Cell2");
				Cell cell2 = sh.getRow(i).getCell(1);
				cell2.setCellType(Cell.CELL_TYPE_STRING);
				String provider_id = cell2.getStringCellValue();

				System.out.println("Cell3");
				Cell cell3 = sh.getRow(i).getCell(2);
				cell3.setCellType(Cell.CELL_TYPE_STRING);
				String npi = cell3.getStringCellValue();
				//System.out.println("Column3");

				System.out.println("Cell4");
				String firstname = sh.getRow(i).getCell(3).getStringCellValue();

				System.out.println("Cell5");
				String lastname = sh.getRow(i).getCell(4).getStringCellValue();

				System.out.println("Cell6");
				Cell cell6 = sh.getRow(i).getCell(5);
				cell6.setCellType(Cell.CELL_TYPE_STRING);
				String location_id = cell6.getStringCellValue();

				System.out.println("Cell7");
				Cell cell7 = sh.getRow(i).getCell(6);
				cell7.setCellType(Cell.CELL_TYPE_STRING);
				String address = cell7.getStringCellValue();

				System.out.println("Cell8");
				String city = sh.getRow(i).getCell(7).getStringCellValue();

				System.out.println("Cell9");
				String state = sh.getRow(i).getCell(8).getStringCellValue();

				System.out.println("Cell10");
				Cell cell10 = sh.getRow(i).getCell(9);
				cell10.setCellType(Cell.CELL_TYPE_STRING);
				String zip = cell10.getStringCellValue();

				System.out.println("Cell11");
				Date date = sh.getRow(i).getCell(10).getDateCellValue();

				Do_not_recruit temporary = new Do_not_recruit(tin, provider_id, npi, firstname, lastname,
						location_id, address, city, state, zip, date);


				res.add(temporary);
			}
		return res;
	}
}
