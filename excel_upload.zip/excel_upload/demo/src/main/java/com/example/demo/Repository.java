package com.example.demo;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface Repository extends MongoRepository<Do_not_recruit, String> {

}