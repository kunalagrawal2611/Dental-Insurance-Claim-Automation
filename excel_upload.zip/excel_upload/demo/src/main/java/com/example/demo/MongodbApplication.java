package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongodbApplication implements CommandLineRunner {

	@Autowired
	private Repository repo;

	public static void main(String[] args)  {
		SpringApplication.run(MongodbApplication.class, args);
	}
	
	@Override
	public void run(String...arg0) {
	}
}
