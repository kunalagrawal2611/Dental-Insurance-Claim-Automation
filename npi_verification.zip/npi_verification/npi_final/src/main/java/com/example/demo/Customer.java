package com.example.demo;

public class Customer {

	private String response;
	private String first_name;
	private String last_name;
	private String middle_name;
	private String nameMatched;
	private String status_Code;
	long t;

	public Customer() {

	}

	public Customer(String response) {
		this.response = response;

	}

	public Customer(String response, String first_name, String last_name, String middle_name, String nameMatched,
			String status_Code) {
		this.response = response;
		this.first_name = first_name;
		this.last_name = last_name;
		this.middle_name = middle_name;
		this.nameMatched = nameMatched;
		this.status_Code = status_Code;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getMiddle_name() {
		return middle_name;
	}

	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}

	public String getNameMatched() {
		return nameMatched;
	}

	public void setNameMatched(String nameMatched) {
		this.nameMatched = nameMatched;
	}

	public String getStatus_Code() {
		return status_Code;
	}

	public void setStatus_Code(String status_Code) {
		this.status_Code = status_Code;
	}

	public boolean ret(String s) {
		String t = s.substring(16, 17);
		int result = Integer.parseInt(t);
		if (result != 0)
			return true;
		else
			return false;
	}

	public String status(String s) {
		int index = s.indexOf("status");
		String ss = s.substring(index + 10, index + 11);
		return ss;
	}

	public String firstname(String s) {
		int index = s.indexOf("first_name");
		int lastindex;
		for (int i = 14;; i++) {
			if (s.charAt(index + i) == ' ') {
				lastindex = index + i;
				break;
			}
		}
		String firstname = s.substring(index + 14, lastindex - 2);

		return firstname;

	}

	public String lastname(String s) {
		int index = s.indexOf("last_name");
		int lastindex;
		for (int i = 13;; i++) {
			if (s.charAt(index + i) == ' ') {
				lastindex = index + i;
				break;
			}
		}
		String lastname = s.substring(index + 13, lastindex - 2);

		return lastname;

	}

	public String middlename(String s) {
		int index = s.indexOf("middle_name");
		int lastindex;
		for (int i = 15;; i++) {
			if (s.charAt(index + i) == ' ') {
				lastindex = index + i;
				break;
			}
		}
		String middlename = s.substring(index + 15, lastindex - 2);

		return middlename;

	}

}
