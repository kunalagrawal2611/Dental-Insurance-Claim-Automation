package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

@RestController
public class DemoController {

	@Autowired
	private RestTemplate restTemplate;

	@RequestMapping("/hello")
	public String hello() {
		return "Hi";
	}

	@RequestMapping("/get")
	public Customer getName(@RequestParam long npi,@RequestParam String firstname,@RequestParam String middlename,
							@RequestParam String lastname)
			throws IOException {
		Customer customer = new Customer();

		String r = "https://npiregistry.cms.hhs.gov/api/?version=2.1&number=" + npi + "&first_name=" + firstname
				+ "&middle_name=" + middlename + "&last_name=" + lastname;
		String s = restTemplate.getForObject(r, String.class);

		Customer failed = new Customer("failed");
		Customer success = new Customer("success", customer.firstname(s), customer.lastname(s), customer.middlename(s),
				"yes", customer.status(s));

		System.out.println(s);
		boolean b = customer.ret(s);
		if (b)
			return success;
		else
			return failed;
	}
}