package com.principal.ApiCall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCallApplicationTests {

	@Test
	void contextLoads() {
	}

}
