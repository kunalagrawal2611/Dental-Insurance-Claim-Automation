package com.principal.ApiCall;

import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.regex.Pattern;

@Controller
public class WebController {

    @Autowired
    private RestTemplate restTemplate;

    @RequestMapping(value="baseui")
    public String baseui(){
        return "baseui";
    }

    @PostMapping("/baseui")
    public String singleFileUpload(@RequestParam("npi") String npi,
                                   @RequestParam("firstName") String firstName,
                                   @RequestParam("middleName") String middleName,
                                   @RequestParam("lastName") String lastName,
                                   @RequestParam("tin") String tin,
                                   @RequestParam("dea") String dea,
                                   RedirectAttributes redirectAttributes, model m) throws Exception{

        String result1="",result2="",result3="",result4="";

        m.setFirstName(firstName.toUpperCase());
        m.setLastName(lastName.toUpperCase());
        m.setNpi(npi);
        m.setTin(tin);
        m.setDeano(dea);

        try {
            String npiverification = "http://npiverification-env.eba-spraj663.ap-south-1.elasticbeanstalk.com/demo/get?npi=" + npi + "&firstname=" + firstName + "&middlename=" + middleName + "&lastname=" + lastName;
            result1 = restTemplate.getForObject(npiverification, String.class);
            m.setNpiverified("Verified");
            m.setNpicolor("green");

            int fir = result1.indexOf("\"first_name\":");
            int mid = result1.indexOf(",\"middle_name\":");
            int las = result1.indexOf(",\"last_name\":");
            int lim = result1.indexOf(",\"nameMatched\":");

            if(result1.indexOf("{\"response\":\"success\"")==0){
                String first1 = result1.substring(fir+14,las-1);
                String second2 = result1.substring(mid+16,lim-1);
                String third3 = result1.substring(las+14,mid-1);
                m.setFullName(first1+" "+second2+" "+third3);
            }
            else {
                m.setFullName("N/A");
            }

        }catch(Exception e) {
            m.setNpiverified("Not Verified");
            m.setNpicolor("red");
            m.setFullName("N/A");
        }

        try{
            String deaverification = "http://deaverfication-env.eba-wfccv3cy.us-east-2.elasticbeanstalk.com/dea/"+dea;
            result2 = restTemplate.getForObject(deaverification, String.class);
            m.setDeaverified("Verified");
            m.setDeacolor("green");

            int com = result2.indexOf(":");
            int stat = result2.indexOf(",\"state\":\"");
            int expi = result2.indexOf(",\"expiration_date\":\"");


            if(!result2.substring(com+1,com+5).equals("null")){
                String companyName = result2.substring(com+2,stat-1);
                m.setDeaname(companyName);
                String stateName = result2.substring(stat+10,expi-1);
                m.setDeastate(stateName);
                String expiration = result2.substring(expi+20,expi+30);
                m.setDeaexpdate(expiration);
            }
            else{
                m.setDeaexpdate("N/A");
                m.setDeaname("N/A");
                m.setDeastate("N/A");
            }

        }catch(Exception e){
            m.setDeaverified("Not Verified");
            m.setDeacolor("red");
            m.setDeaexpdate("N/A");
            m.setDeaname("N/A");
            m.setDeastate("N/A");
        }

        try{

            String do_not_lookup ="http://donotrecruitverification-env.eba-n5cnnb6u.ap-south-1.elasticbeanstalk.com/get/doNotRecruitLookup?firstname="+firstName+"&lastname="+lastName+"&npi="+npi;
            result3 = restTemplate.getForObject(do_not_lookup, String.class);
            m.setDonotlookupverified("Verified");
            m.setDnrcolor("green");


            if(result3.indexOf("\"nameMatched\":\"yes\"")!=-1){
                m.setNamednrpresent("Yes");
            }
            else {
                m.setNamednrpresent("No");
            }

            int st = result3.indexOf("npiMatched");
            if(result3.indexOf("npiMatched\":\"yes\"}")!=-1){
                m.setNpipresent("Yes");
            }
            else{
                m.setNpipresent("No");
            }
        }catch (Exception e){
            m.setDonotlookupverified("Not Verified");
            m.setDnrcolor("red");
            m.setNpipresent("N/A");
            m.setNamednrpresent("N/A");
        }

        try{
            String tinlookup ="http://donotrecruitverification-env.eba-n5cnnb6u.ap-south-1.elasticbeanstalk.com/get/doNotRecruitLookup/tin?tin="+tin;
            result4 = restTemplate.getForObject(tinlookup, String.class);
            if(result4.contains("no")) m.setTinpresent("No");
            else m.setTinpresent("Yes");
        }catch(Exception e){
            m.setTinpresent("N/A");
        }


        return "verifiedlookup";
    }

}
