package com.principal.ApiCall;

public class model {
    public String npiverified;
    public String donotlookupverified;
    public String deaverified;

    public String npicolor;
    public String dnrcolor;
    public String deacolor;

    public String firstName;
    public String lastName;
    public String npi;
    public String fullName;
    public String tin;

    public String deano;
    public String deaname;
    public String deastate;
    public String deaexpdate;

    public String namednrpresent;
    public String tinpresent;
    public String npipresent;

    public model(){}

    public void setNpiverified(String npiverified){
        this.npiverified=npiverified;
    }
    public void setDeaverified(String deaverified){ this.deaverified=deaverified; }
    public void setDonotlookupverified(String donotlookupverified){
        this.donotlookupverified=donotlookupverified;
    }

    public void setNpicolor(String npicolor){this.npicolor=npicolor;}
    public void setDnrcolor(String dnrcolor){this.dnrcolor=dnrcolor;}
    public void setDeacolor(String deacolor){this.deacolor=deacolor;}

    public void setFirstName(String firstName){this.firstName=firstName;}
    public void setLastName(String lastName){this.lastName=lastName;}
    public void setNpi(String npi){this.npi=npi;}
    public void setFullName(String fullName){this.fullName=fullName;}
    public void setTin(String tin){this.tin=tin;}



    public void setDeaname(String deaname){this.deaname=deaname;}
    public void setDeastate(String deastate){this.deastate=deastate;}
    public void setDeaexpdate(String deaexpdate){this.deaexpdate=deaexpdate;}
    public void setDeano(String deano){this.deano=deano;}

    public void setNamednrpresent(String namednrpresent){this.namednrpresent=namednrpresent;}
    public void setNpipresent(String npipresent){this.npipresent=npipresent;}
    public void setTinpresent(String tinpresent){this.tinpresent=tinpresent;}
}
